package hw3;

public class ClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Item item = new Item(111,"box", 44);
		
		NewItem newitem = new NewItem(item, 20);
		
		System.out.println(item.cost(1000));
		System.out.println(newitem.cost(1000));
		
	}

}
